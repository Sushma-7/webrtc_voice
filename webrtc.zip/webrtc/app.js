// const express = require("express");
// const multer = require("multer");
// const cors = require("cors");
// const path = require("path");

// const app = express();
// const port = 3000;

// // Enable CORS
// app.use(cors());

// // Serve static files (index.html, style.css, script.js)
// app.use(express.static(path.join(__dirname, "public")));

// // Multer storage setup
// const storage = multer.diskStorage({
//   destination: "./uploads/",
//   filename: (req, file, cb) => {
//     cb(null, `audio_${Date.now()}${path.extname(file.originalname)}`);
//   },
// });
// const upload = multer({ storage });

// // Upload route
// app.post("/upload", upload.single("audio"), (req, res) => {
//   res.json({ message: "File uploaded successfully!", file: req.file });
// });

// // Start server
// app.listen(port, () => {
//   console.log(`Server running at http://localhost:${port}`);
// });



// const express = require("express");
// const multer = require("multer");
// const cors = require("cors");
// const path = require("path");
// const http = require("http");
// const { Server } = require("socket.io");

// const app = express();
// const port = 3000;
// const server = http.createServer(app);
// const io = new Server(server);

// // Enable CORS
// app.use(cors());
// app.use(express.static(path.join(__dirname, "public")));

// // Multer storage setup
// const storage = multer.diskStorage({
//   destination: "./uploads/",
//   filename: (req, file, cb) => {
//     cb(null, `audio_${Date.now()}${path.extname(file.originalname)}`);
//   },
// });
// const upload = multer({ storage });

// // WebRTC Signaling
// io.on("connection", (socket) => {
//     console.log("New WebRTC Connection");

//     socket.on("offer", (offer) => {
//         socket.broadcast.emit("offer", offer);
//     });

//     socket.on("answer", (answer) => {
//         socket.broadcast.emit("answer", answer);
//     });

//     socket.on("ice-candidate", (candidate) => {
//         socket.broadcast.emit("ice-candidate", candidate);
//     });
// });

// // Upload route
// app.post("/upload", upload.single("audio"), async (req, res) => {
//     if (!req.file) {
//         return res.status(400).json({ error: "No file uploaded" });
//     }

//     res.json({
//         message: "File uploaded successfully!",
//         file: req.file,
//     });
// });

// // Start server
// server.listen(port, () => {
//     console.log(`Server running at http://localhost:${port}`);
// });

const express = require("express");
const multer = require("multer");
const cors = require("cors");
const path = require("path");
const axios = require("axios");
const cheerio = require("cheerio");

const app = express();
const port = 3000;

app.use(cors());
app.use(express.static(path.join(__dirname, "public")));

const storage = multer.diskStorage({
  destination: "./uploads/",
  filename: (req, file, cb) => {
    cb(null, `audio_${Date.now()}${path.extname(file.originalname)}`);
  },
});
const upload = multer({ storage });

app.get("/search", async (req, res) => {
    const query = req.query.query;
    console.log("Received search query:", query);

    try {
        const senaResponse = await axios.get("https://sena.services");
        const $ = cheerio.load(senaResponse.data);

        let result = $("body").text().slice(0, 500); 

        if (!result) {
            console.log("Sena Services data not found, fetching cricket results...");
            result = await fetchCricketResults();
        }

        res.json({ result });
    } catch (error) {
        console.error("Error fetching Sena Services:", error);
        const fallbackResult = await fetchCricketResults();
        res.json({ result: fallbackResult });
    }
});

async function fetchCricketResults() {
    try {
        const cricketResponse = await axios.get("https://www.espncricinfo.com/");
        const $ = cheerio.load(cricketResponse.data);
        
        let matchResults = [];
        $(".match-info").each((index, element) => {
            matchResults.push($(element).text().trim());
        });

        return matchResults.length > 0 ? matchResults.join("\n") : "No cricket results found.";
    } catch (error) {
        console.error("Error fetching cricket results:", error);
        return "Unable to fetch cricket results.";
    }
}

app.post("/upload", upload.single("audio"), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
    }

    res.json({ message: "File uploaded successfully!", file: req.file });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
