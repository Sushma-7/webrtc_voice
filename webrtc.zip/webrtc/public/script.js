
// let mediaRecorder;
// let audioChunks = [];
// let peerConnection;
// let dataChannel;
// const open_api_key = "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"; // Replace with your OpenAI API key

// const config = {
//     iceServers: [{ urls: "stun:stun.l.google.com:19302" }]
// };

// async function initWebRTC() {
//     peerConnection = new RTCPeerConnection(config);
//     dataChannel = peerConnection.createDataChannel("audioData");

//     peerConnection.onicecandidate = (event) => {
//         if (event.candidate) {
//             console.log("ICE Candidate:", event.candidate);
//         }
//     };
// }

// document.getElementById("startRecord").addEventListener("click", async () => {
//     await initWebRTC();
//     const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

//     mediaRecorder = new MediaRecorder(stream);
//     mediaRecorder.start();
//     audioChunks = [];

//     mediaRecorder.ondataavailable = (event) => {
//         audioChunks.push(event.data);
//         if (dataChannel.readyState === "open") {
//             dataChannel.send(event.data);
//         }
//     };

//     document.getElementById("startRecord").disabled = true;
//     document.getElementById("stopRecord").disabled = false;
// });

// document.getElementById("stopRecord").addEventListener("click", () => {
//     mediaRecorder.stop();
//     mediaRecorder.addEventListener("stop", async () => {
//         const audioBlob = new Blob(audioChunks, { type: "audio/wav" });
//         const audioUrl = URL.createObjectURL(audioBlob);
//         document.getElementById("audioPlayback").src = audioUrl;
//         document.getElementById("uploadAudio").disabled = false;
//     });

//     document.getElementById("startRecord").disabled = false;
//     document.getElementById("stopRecord").disabled = true;
// });

// document.getElementById("uploadAudio").addEventListener("click", async () => {
//     const formData = new FormData();
//     formData.append("file", new Blob(audioChunks, { type: "audio/wav" }));
//     formData.append("model", "whisper-1");

//     try {
//         // Send audio to OpenAI Whisper for transcription
//         const openAiResponse = await fetch("https://api.openai.com/v1/audio/transcriptions", {
//             method: "POST",
//             headers: { "Authorization": `Bearer ${open_api_key}` },
//             body: formData
//         });

//         const openAiData = await openAiResponse.json();
//         document.getElementById("transcription").innerText = "Transcription: " + openAiData.text;

//         // Fetch results from Sena Services
//         fetchSearchResults(openAiData.text);

//     } catch (error) {
//         console.error("Error:", error);
//     }
// });

// async function fetchSearchResults(query) {
//     try {
//         const response = await fetch(`http://localhost:3000/search?query=${encodeURIComponent(query)}`);
//         const data = await response.json();
//         document.getElementById("searchResults").innerText = "Search Results: " + data.result;
//     } catch (error) {
//         console.error("Error fetching search results:", error);
//     }
// }
let mediaRecorder;
let audioChunks = [];
let peerConnection;
let dataChannel;
const open_api_key = "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"; // Replace with your actual API key

const config = {
    iceServers: [{ urls: "stun:stun.l.google.com:19302" }]
};

async function initWebRTC() {
    peerConnection = new RTCPeerConnection(config);
    dataChannel = peerConnection.createDataChannel("audioData");

    peerConnection.onicecandidate = (event) => {
        if (event.candidate) {
            console.log("ICE Candidate:", event.candidate);
        }
    };
}

document.getElementById("startRecord").addEventListener("click", async () => {
    await initWebRTC();
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

    mediaRecorder = new MediaRecorder(stream);
    mediaRecorder.start();
    audioChunks = [];

    mediaRecorder.ondataavailable = (event) => {
        audioChunks.push(event.data);
        if (dataChannel.readyState === "open") {
            dataChannel.send(event.data);
        }
    };

    document.getElementById("startRecord").disabled = true;
    document.getElementById("stopRecord").disabled = false;
});

document.getElementById("stopRecord").addEventListener("click", () => {
    mediaRecorder.stop();
    mediaRecorder.addEventListener("stop", async () => {
        const audioBlob = new Blob(audioChunks, { type: "audio/wav" });
        const audioUrl = URL.createObjectURL(audioBlob);
        document.getElementById("audioPlayback").src = audioUrl;
        document.getElementById("uploadAudio").disabled = false;
    });

    document.getElementById("startRecord").disabled = false;
    document.getElementById("stopRecord").disabled = true;
});

document.getElementById("uploadAudio").addEventListener("click", async () => {
    const formData = new FormData();
    formData.append("file", new Blob(audioChunks, { type: "audio/wav" }));
    formData.append("model", "whisper-1");

    try {
        const openAiResponse = await fetch("https://api.openai.com/v1/audio/transcriptions", {
            method: "POST",
            headers: { "Authorization": `Bearer ${open_api_key}` },
            body: formData
        });

        const openAiData = await openAiResponse.json();
        document.getElementById("transcription").innerText = "Transcription: " + openAiData.text;

        fetchSearchResults(openAiData.text);

    } catch (error) {
        console.error("Error:", error);
    }
});

async function fetchSearchResults(query) {
    try {
        const openAiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: {
                "Authorization": `Bearer ${open_api_key}`,
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                model: "gpt-4-turbo",
                messages: [
                    { role: "system", content: "You are a helpful assistant that provides accurate and structured search results." },
                    { role: "user", content: `Search the internet for: ${query}. Return a well-formatted response with key details.` }
                ],
                temperature: 0.5
            }),
        });

        const openAiData = await openAiResponse.json();
        document.getElementById("searchResults").innerText = "Search Results: " + openAiData.choices[0].message.content;

    } catch (error) {
        console.error("Error fetching search results:", error);
    }
}

document.getElementById("startCall").addEventListener("click", async () => {
    peerConnection = new RTCPeerConnection(config);

    peerConnection.onicecandidate = (event) => {
        if (event.candidate) {
            console.log("ICE Candidate:", event.candidate);
        }
    };

    peerConnection.ontrack = (event) => {
        console.log("Received audio stream from OpenAI");
        document.getElementById("audioPlayback").srcObject = event.streams[0];
        document.getElementById("audioPlayback").play();
    };

    const microphoneStream = await navigator.mediaDevices.getUserMedia({ audio: true });

    microphoneStream.getTracks().forEach((track) => {
        peerConnection.addTrack(track, microphoneStream);
    });

    const offer = await peerConnection.createOffer();
    await peerConnection.setLocalDescription(offer);

    const response = await fetch("http://localhost:3000/start-call", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ offer })
    });

    const { answer } = await response.json();
    await peerConnection.setRemoteDescription(new RTCSessionDescription(answer));

    document.getElementById("startCall").disabled = true;
    document.getElementById("stopCall").disabled = false;
});

document.getElementById("stopCall").addEventListener("click", () => {
    if (peerConnection) {
        peerConnection.close();
    }
    document.getElementById("startCall").disabled = false;
    document.getElementById("stopCall").disabled = true;
});
